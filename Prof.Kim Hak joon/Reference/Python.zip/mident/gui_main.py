"""
@author: Gerrit Renner
date: 2019-02-06

title: main gui
"""

# LOAD PACKAGES
# external
import tkinter
from tkinter import ttk
from PIL import Image, ImageTk
import numpy as np
import os

# internal
from mident_cfg import *
from mident_import import *
from mident_database import *
from mident_libsearch import *
from mident_mapping import *

class App():
    def __init__(self):
        self.root = tkinter.Tk()
        self.root.attributes('-fullscreen', False)
        self.root.geometry('1240x860')
        self.root.configure(background='#333333')
        bt_close = tkinter.Button(self.root, text = 'X', command=self.quit, height=1, width=3, bg='#c54040', fg='#eeeeee', font=(None, 15, 'bold'), relief='groove')
        bt_close.pack(side='top', anchor='ne')
        
        # Main Frame
        self.window_width = self.root.winfo_screenwidth()
        self.window_height = self.root.winfo_screenheight()
        self.frame_main = tkinter.Frame(self.root, bg='#333333', width=self.window_width-100, height=self.window_height-50, padx=50)
        self.logo = Image.open("midentlogo.png")
        width = np.size(self.logo, axis=1)
        height = np.size(self.logo, axis=0)
        self.logo = self.logo.resize((int(width/4),int(height/4)), Image.ANTIALIAS)
        self.logo = ImageTk.PhotoImage(self.logo)
        self.logo_frame = tkinter.Label(self.root, image=self.logo,borderwidth=0).pack(side='top', anchor='n')
        self.status_text = tkinter.StringVar()
        self.status_text.set('Home')
        self.status = tkinter.Label(self.root, textvariable=self.status_text, bg='#333333', fg='#67d132', font=(None, 15, 'bold')).pack()
                                    
        # Side Menu
        self.frame_sidemenu = tkinter.Frame(self.root, width=100, height=100)
        self.frame_sidemenu.pack(side='left')       
        self.frame_main.pack(side='left')
        module_array = np.array([lambda: module_database(self.frame_main, self.status_text),lambda: module_import(self.frame_main,'reference', self.status_text, self.root), lambda: module_import(self.frame_main,'sample', self.status_text, self.root), lambda: module_libsearch(self.frame_main, self.status_text, self.root), lambda: module_cfg(self.frame_main, self.status_text, self.root),lambda: module_mapping(self.frame_main, self.status_text, self.root)])
        self.create_menu(module_array)
        
        # define styles
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('TEntry', fieldbackground='#282828', foreground='#89B594', bordercolor='#333333', lightcolor='#333333', background='#333333')
        style.configure('TLabel', background='#333333', foreground='#dddddd')
        style.configure(".", font=('Helvetica', 15), background="#333333", fieldbackground='#333333', bordercolor='#333333', lightcolor='#333333')
        style.configure("Treeview", foreground='#89B594', background='#333333', bordercolor='#333333', lightcolor='#333333')
        style.configure("Treeview.Heading", font=('Helvetica', 15, 'bold'), foreground='#FFDA8F', bordercolor='#333333', lightcolor='#333333', background='#333333', borderwidth=0)
        style.map("Treeview.Heading", background=[('focus', '#333333'),('!focus', '#333333')])
        style.configure("menu.TButton", width=80, cursor='hand2', bordercolor='#333333', lightcolor='#333333', borderwidth=0, background='#333333')
        style.map("menu.TButton",background=[('focus', '#333333'),('!focus', '#333333')])

        # check if database exists
        master_path = os.path.dirname(__file__)
        master_path = master_path[0:master_path.find("\\" + "Python" + "\\") + 8] + 'database' + '\\'
        database_master_file = master_path + 'database.csv'
        if os.path.isdir(master_path):
            if not os.path.exists(database_master_file):
                with open(database_master_file, 'w', newline='') as csvfile:
                    exportdata = csv.writer(csvfile, delimiter=',')
                    exportdata.writerow(['ID','TYPE','NAME','DATE','RAWDATA','RESULTS'])
        else:
            os.makedirs(master_path)
            with open(database_master_file, 'w', newline='') as csvfile:
                    exportdata = csv.writer(csvfile, delimiter=',')
                    exportdata.writerow(['ID','TYPE','NAME','DATE','RAWDATA','RESULTS'])
        
        self.root.mainloop()

    def quit(self):
        self.root.destroy()
    
    def create_menu(self, module):
        self.button_list = ['btmmDatabase1.png','btmmImport1.png','btmmImports1.png', 'btmmLibsearch1.png', 'btmmCfg1.png', 'btmmSmartaim1.png']
        self.button_image_array = np.array([])
        self.button_image_array2 = np.array([])
        for self.button_name in self.button_list:
            self.filename = 'icons/' + self.button_name
            self.filename2 = self.filename[:-5] + '2.png'
            self.image = Image.open(self.filename)
            self.image = self.image.resize((80, 80),Image.ANTIALIAS)
            self.image = ImageTk.PhotoImage(self.image)
            self.button_image_array = np.append(self.button_image_array, self.image)
            self.image2 = Image.open(self.filename2)
            self.image2 = self.image2.resize((80, 80),Image.ANTIALIAS)
            self.image2 = ImageTk.PhotoImage(self.image2)
            self.button_image_array2 = np.append(self.button_image_array2, self.image2)
        
        
        self.button_database = ttk.Button(self.frame_sidemenu, style='menu.TButton', image=self.button_image_array[0], command=module[0])
        self.button_database.bind("<Enter>", lambda event, h=self.button_database: h.configure(image=self.button_image_array2[0]))     
        self.button_database.bind("<Leave>", lambda event, h=self.button_database: h.configure(image=self.button_image_array[0]))        
        
        self.button_importref = ttk.Button(self.frame_sidemenu, style='menu.TButton', image=self.button_image_array[1], command=module[1])
        self.button_importref.bind("<Enter>", lambda event, h=self.button_importref: h.configure(image=self.button_image_array2[1]))     
        self.button_importref.bind("<Leave>", lambda event, h=self.button_importref: h.configure(image=self.button_image_array[1]))        
        
        self.button_importsmp = ttk.Button(self.frame_sidemenu, style='menu.TButton', image=self.button_image_array[2], command=module[2])
        self.button_importsmp.bind("<Enter>", lambda event, h=self.button_importsmp: h.configure(image=self.button_image_array2[2]))     
        self.button_importsmp.bind("<Leave>", lambda event, h=self.button_importsmp: h.configure(image=self.button_image_array[2]))        
        
        self.button_libsearch = ttk.Button(self.frame_sidemenu, style='menu.TButton', image=self.button_image_array[3], command=module[3])
        self.button_libsearch.bind("<Enter>", lambda event, h=self.button_libsearch: h.configure(image=self.button_image_array2[3]))     
        self.button_libsearch.bind("<Leave>", lambda event, h=self.button_libsearch: h.configure(image=self.button_image_array[3]))  

        self.button_cfg = ttk.Button(self.frame_sidemenu, style='menu.TButton', image=self.button_image_array[4], command=module[4])
        self.button_cfg.bind("<Enter>", lambda event, h=self.button_cfg: h.configure(image=self.button_image_array2[4]))     
        self.button_cfg.bind("<Leave>", lambda event, h=self.button_cfg: h.configure(image=self.button_image_array[4]))   

        self.button_mapping = ttk.Button(self.frame_sidemenu, style='menu.TButton', image=self.button_image_array[5], command=module[5])
        self.button_mapping.bind("<Enter>", lambda event, h=self.button_mapping: h.configure(image=self.button_image_array2[5]))     
        self.button_mapping.bind("<Leave>", lambda event, h=self.button_mapping: h.configure(image=self.button_image_array[5]))       
        
        self.button_importref.pack()
        self.button_importsmp.pack()
        self.button_database.pack()
        self.button_libsearch.pack()
        self.button_cfg.pack()    
        self.button_mapping.pack()
             
root = App()

