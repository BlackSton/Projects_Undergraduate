"""
@author: Gerrit Renner
date: 2019-02-06

title: database module
"""

# LOAD PACKAGES
# external
import os
import csv
from tkinter import ttk
import tkinter
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib
import numpy as np

class module_database:
    def __init__(self, master, status):
        for widget in master.winfo_children():
            widget.destroy()
        self.master = master
        status.set('Database')
        
        # load database
        '''___Master Path___________________________________________________'''
        master_path = os.path.dirname(__file__)
        master_path = master_path[0:master_path.find("\\" + "Python" + "\\") + 8] + 'database' + '\\'
        database_master_file = master_path + 'database.csv'
        
        with open(database_master_file) as csvfile:
            database_master_csv = csv.reader(csvfile, delimiter=',')
            database_ID = []
            database_TYPE = []
            database_NAME = []
            database_DATE = []
            database_RAWDATA = []
            database_RESULTS = []
            for row in database_master_csv:
                if len(row) > 0:
                    database_ID.append(row[0])
                    database_TYPE.append(row[1])
                    database_NAME.append(row[2])
                    database_DATE.append(row[3])
                    database_RAWDATA.append(row[4])
                    database_RESULTS.append(row[5])
        # create table
        table_header = ['ID', 'TYPE', 'NAME', 'DATE', 'RAWDATA']
        column_widths = (150, 150, 300, 200, 300)
        self.tree = ttk.Treeview(master = master, columns=table_header, show="headings", height=20)
        self.tree.grid(column=0, row=1, sticky='nsew', in_=master)
        master.grid_columnconfigure(0, weight=1)
        master.grid_rowconfigure(0, weight=1)
        # set headings
        for ix in enumerate(table_header):
            self.tree.heading(table_header[ix[0]], text=table_header[ix[0]], anchor='w')
            self.tree.column(table_header[ix[0]], width=column_widths[ix[0]])
        # set items
        for i in range(1,len(database_NAME)):
            item = [database_ID[i], database_TYPE[i], database_NAME[i], database_DATE[i], database_RAWDATA[i]]
            self.tree.insert('', 'end', values=item)
            
        # open data => double click
        self.tree.bind("<Double-1>", self.OnDoubleClick)
        self.tree.bind("<Delete>", self.OnDelete)
        # create edit frame
        self.edit_frame = tkinter.Frame(master, width=1100, height=200, bg='#333333')
        self.edit_frame.grid(row=0, column=0)
    
    def OnDelete(self, event):
        item = self.tree.selection()[0]
        # read item        
        item_dict = self.tree.item(item)
        item = item_dict.get('values')
        # delete Raw data
        file_name = item[4]
        os.remove(file_name)
        # delte Results file
        file_name = file_name.replace('_raw.csv','_results.csv')
        os.remove(file_name)
        # delte entry from database
        '''___Master Path___________________________________________________'''
        master_path = os.path.dirname(__file__)
        master_path = master_path[0:master_path.find("\\" + "Python" + "\\") + 8] + 'database' + '\\'
        database_master_file = master_path + 'database.csv'
        with open(database_master_file) as csvfile:
            database_master_csv = csv.reader(csvfile, delimiter=',')
            database_ID = []
            database_TYPE = []
            database_NAME = []
            database_DATE = []
            database_RAWDATA = []
            database_RESULTS = []
            for row in database_master_csv:
                if len(row) > 0:
                    if row[0] != str(item[0]):
                        database_ID.append(row[0])
                        database_TYPE.append(row[1])
                        database_NAME.append(row[2])
                        database_DATE.append(row[3])
                        database_RAWDATA.append(row[4])
                        database_RESULTS.append(row[5])
        with open(database_master_file, 'w') as csvfile:
            database_master_csv = csv.writer(csvfile, delimiter=',')
            for row in range(0,len(database_NAME)):
                database_master_csv.writerow([database_ID[row], database_TYPE[row], database_NAME[row], database_DATE[row], database_RAWDATA[row], database_RESULTS[row]])
        self.__init__(self.master)
        
    def OnDoubleClick(self, event):
        for widget in self.edit_frame.winfo_children():
            widget.destroy()
        item = self.tree.selection()[0]
        # read item        
        item_dict = self.tree.item(item)
        item = item_dict.get('values')
        # load raw data
        with open(item[-1]) as csvfile:
            rawdata = csv.reader(csvfile, delimiter=',')
            data = []
            for row in rawdata:
                data.append(row)

        # load fitted data
        fit_item = item[-1][:-7] + 'fit.csv'
        with open(fit_item) as csvfile:
            fitdata = csv.reader(csvfile, delimiter=',')
            fdata = []
            for row in fitdata:
                fdata.append(row)
        # get frame size
        width = 1100
        height = 200
        
        f = Figure(figsize=(width/100,height/100),
                   dpi=100, facecolor='#333333')
        
        a = f.add_subplot(111,facecolor='#333333')
        for child in a.get_children():
            if isinstance(child, matplotlib.spines.Spine):
                child.set_color('#bbbbbb')
        a.set_xlabel('wavenumber [cm-1]',fontweight='bold', fontsize=12)
        a.set_ylabel('abs.',fontweight='bold', fontsize=12)
        a.xaxis.label.set_color('#bbbbbb')
        a.yaxis.label.set_color('#bbbbbb')
        a.tick_params(axis='x', colors='#bbbbbb')
        a.tick_params(axis='both', which='both', bottom=False, top=False, labelbottom=False, right=False, left=False, labelleft=False)
        a.invert_xaxis()
        x = data[0]
        y = data[1]
        x = list(np.float_(x))
        y = list(np.float_(y))

        fx = fdata[0]
        fy = fdata[1]
        fb = fdata[3]
        fx = list(np.float_(fx))
        fy = list(np.float_(fy) + np.float_(fb))
        fb = list(np.float_(fb))
        a.plot(x,y,lw=2,color='#666666')
        a.plot(fx,fy,lw=2,color='#EE3135')
        f.set_tight_layout(True)
        canvas = FigureCanvasTkAgg(f, self.edit_frame)
        canvas.draw()
        
        canvas.get_tk_widget().pack(side=tkinter.BOTTOM, fill=tkinter.BOTH, expand=True)
        canvas._tkcanvas.pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=True)       
