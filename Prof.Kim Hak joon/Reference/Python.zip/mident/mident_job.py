"""
@author: Gerrit Renner
date: 2019-02-06

title: job module
"""

# LOAD PACKAGES
# external
from dateutil.parser import parse
from tkinter import ttk
import tkinter

#internal
from mident_fit import *

class module_job:
    def __init__(self, master, fnames, type_, status, main):
        for widget in master.winfo_children():
            widget.destroy()
        # get entries
        items = []
        for item in fnames:
            tmp_type = type_
            tmp_name, tmp_date = self.get_filename(item)
            tmp_item = (tmp_type, tmp_name, tmp_date)
            items.append(tmp_item)
        # create table
        table_header = ['TYPE', 'FILE NAME', 'DATE']
        column_widths = (150, 300, 200)
        self.tree = ttk.Treeview(master = master, columns=table_header, show="headings", height=20)
        self.tree.grid(column=0, row=1, sticky='nsew', in_=master)
        master.grid_columnconfigure(0, weight=1)
        master.grid_rowconfigure(0, weight=1)
        # set headings
        for ix in enumerate(table_header):
            self.tree.heading(table_header[ix[0]], text=table_header[ix[0]], anchor='w')
            self.tree.column(table_header[ix[0]], width=column_widths[ix[0]])
        # set items
        for item in items:
            self.tree.insert('', 'end', values=item)
            
        self.tree.bind("<Double-1>", self.OnDoubleClick)
        # create edit frame
        self.edit_frame = tkinter.Frame(master, width=670, height=200, bg='#333333')
        self.edit_frame.grid(row=0, column=0)
        # create run button
        self.run_button = tkinter.Button(master, text='Start Curve Fitting',
                                         font=(None, 15, 'bold'), width=55,
                                         relief='groove', bg='#317256',
                                         fg='#dddddd', command= lambda: module_fit(master, fnames,items, status, main))
        self.run_button.grid(row=2, column=0, sticky='n') 
    
    def get_filename(self, filename):
        # delete path
        flag = 0
        while flag == 0:
            ix = filename.find('/')
            if ix != -1:
                filename = filename[ix+1:]
            else:
                flag = 1
        # delete ending
        ix = filename.find('.')
        filename = filename[0:ix]
        # extract date
        try:
            ix = filename.find('_')
            date = filename[0:ix]
            try:
                tmp = int(date[0])
                month = ''
                for i in range(len(date)):
                    try:
                        tmp = int(date[i])
                    except:
                        month = month + date[i]
                ix2 = date.find(month)
                _len = len(month)
                if month == 'i' or month == 'I':
                    month = '01'
                elif month == 'ii' or month == 'II':
                    month = '02'
                elif month == 'iii' or month == 'III':
                    month = '03'
                elif month == 'iv' or month == 'IV':
                    month = '04'
                elif month == 'v' or month == 'V':
                    month = '05'
                elif month == 'vi' or month == 'VI':
                    month = '06'
                elif month == 'vii' or month == 'VII':
                    month = '07'
                elif month == 'viii' or month == 'VIII':
                    month = '08'
                elif month == 'ix' or month == 'IX':
                    month = '09'
                elif month == 'x' or month == 'X':
                    month = '10'
                elif month == 'xi' or month == 'XI':
                    month = '11'
                elif month == 'xii' or month == 'XII':
                    month = '12'
                if ix2 > 0:
                    year = date[0:ix2]
                    day = date[ix2+_len:]
                else:
                    if len(date) == 6:
                        year = '20' + date[0:2]
                        month = date[2:4]
                        day = date[4:6]
                    else:
                        year = '2015'
                        month = '08'
                        day = '01'

                date = str(year) + '-' + month + '-' + str(day)
                name = filename[ix+1:]
                flag = False
            except:
                date = '2015-8-1'
                name = filename
                flag = True
        except:
            date = '2015-8-1'
            name = filename
            flag = True
        if flag:
            try:
                date = parse(filename[0:8], yearfirst=True)
                date = str(date.year) + '-' + str(date.month) + '-' + str(date.day)
                name = filename[9:]
            except ValueError as err:
                date = '2015-8-1'
                name = filename
        return name, date
            
        
    def OnDoubleClick(self, event):
        item = self.tree.selection()[0]
        self.Edit(item)
    
    def Edit(self, item):
        for widget in self.edit_frame.winfo_children():
            widget.destroy()       
        # read item        
        item_dict = self.tree.item(item)
        item_ID = item
        item = item_dict.get('values')
        # set labels
        self.type_lbl = ttk.Label(self.edit_frame,text='type: ',
                                      font=(None, 15, 'bold')).grid(row=1, sticky='e')
        self.name_lbl = ttk.Label(self.edit_frame,text='file name: ',
                                      font=(None, 15, 'bold')).grid(row=2, sticky='e')
        self.date_lbl = ttk.Label(self.edit_frame,text='date: ',
                                      font=(None, 15, 'bold')).grid(row=3, sticky='e')
        # set entries
        self.entry_type = ttk.Entry(self.edit_frame, font=(None, 15, 'bold'))
        self.entry_name = ttk.Entry(self.edit_frame, font=(None, 15, 'bold'))
        self.entry_date = ttk.Entry(self.edit_frame, font=(None, 15, 'bold'))
        # set buttons
        self.apply = tkinter.Button(self.edit_frame, text='Apply', font=(None, 15, 'bold'),
                                    command= lambda: self.Update_Job(item_ID),
                                    relief='groove', bg='#317256', fg='#dddddd')
        self.delete = tkinter.Button(self.edit_frame, text='Delete Sample', font=(None, 15, 'bold'),
                                    command= lambda: self.Update_Job(item_ID),
                                    relief='groove', bg='#c54040', fg='#dddddd')
        # preset entry values
        self.entry_type.insert(0,item[0])
        self.entry_name.insert(0,item[1])
        self.entry_date.insert(0,item[2])
        # place entries
        self.entry_type.grid(row=1, column=1)
        self.entry_name.grid(row=2, column=1)
        self.entry_date.grid(row=3, column=1)
        # place buttons
        self.apply.grid(row=1, column=2, rowspan=3)
        self.delete.grid(row=1, column=3, rowspan=3)
        # set placeholder for minimum frame size
        self.placeholder_width = tkinter.Frame(self.edit_frame, bg='#333333', width=670, height=55)
        self.placeholder_width.grid(row=0, column=0, columnspan=4)
        self.placeholder_width = tkinter.Frame(self.edit_frame, bg='#333333', width=670, height=55)
        self.placeholder_width.grid(row=4, column=0, columnspan=4)
    
    def Update_Job(self, item):
        new_value = (self.entry_type.get(),
                     self.entry_name.get(),
                     self.entry_date.get())
        for widget in self.edit_frame.winfo_children():
            widget.destroy()
        self.tree.item(item, values=new_value)