"""
@author: Gerrit Renner
date: 2019-02-06

title: mapping module
"""

class module_mapping:
	def __init__(self, master, status, main):
		for widget in master.winfo_children():
			widget.destroy()
		self.master = master
		status.set('Mapping will be supported in future releases.')