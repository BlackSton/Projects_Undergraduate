"""
@author: Gerrit Renner
date: 2019-02-06

title: import module
"""

# LOAD PACKAGES
# external
from tkinter.filedialog import askopenfilenames

# internal
from mident_job import *

class module_import:
    def __init__(self, master, type_, status, main):
        for widget in master.winfo_children():
            widget.destroy()
        fname = askopenfilenames(filetypes=(("Shimadzu AIM 9000", "*.apit"),
                                           ("Shimadzu AIM 9000", "*.amap"),
                                           ("CSV files", "*.csv"),
                                           ("TXT files", "*.txt")))
        if fname:
            module_job(master, fname, type_, status, main)