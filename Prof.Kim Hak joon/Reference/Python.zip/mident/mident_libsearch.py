"""
@author: Gerrit Renner
date: 2019-02-06

title: library search module
"""

# LOAD PACKAGES
# external
import csv
import tkinter
import numpy as np
np.seterr(divide='ignore', invalid='ignore')
from tkinter.filedialog import askopenfilenames, asksaveasfilename

class module_libsearch:
    def __init__(self, master, status, main):
        for widget in master.winfo_children():
            widget.destroy()
        status.set('Library Search')
        # create buttons
        self.load_references_button_text = tkinter.StringVar()
        self.load_references_button_text.set('Load References')
        self.load_references_button = tkinter.Button(master, textvariable=self.load_references_button_text,
                                         font=(None, 15, 'bold'), width=55,
                                         relief='groove', bg='#e22b0b',
                                         fg='#dddddd', command= lambda: self.load_references(self.load_references_button_text))

        self.load_samples_button_text = tkinter.StringVar()
        self.load_samples_button_text.set('Load Samples')
        self.load_samples_button = tkinter.Button(master, textvariable=self.load_samples_button_text,
                                         font=(None, 15, 'bold'), width=55,
                                         relief='groove', bg='#e22b0b',
                                         fg='#dddddd', command= lambda: self.load_samples(self.load_samples_button_text))

        self.run_button_text = tkinter.StringVar()
        self.run_button_text.set('Run Search')
        self.run_button = tkinter.Button(master, textvariable=self.run_button_text,
                                         font=(None, 15, 'bold'), width=55,
                                         relief='groove', bg='#bab6b6',
                                         fg='#dddddd', command= lambda: self.run_search())
        
        self.load_references_button.grid(row=0, column=0, sticky='n')
        self.load_samples_button.grid(row=1, column=0, sticky='n') 
        self.run_button.grid(row=2, column=0, sticky='n',pady=20) 

    def load_references(self,button):
        self.ref_files = askopenfilenames(filetypes=(("Reference files", "*_REF_results.csv"),))
        button.set(str(len(self.ref_files)) + ' Reference(s) Loaded')
        self.load_references_button.configure(background='#317256')
        try:
            if len(self.ref_files) * len(self.smp_files) > 0:
                self.run_button.configure(background='#317256')
        except:
            pass
        self.ref_names = ["samples \ references: "]
        for i in range(len(self.ref_files)):
            _idx = self.ref_files[i].rfind('/')
            _idx2 = self.ref_files[i].rfind('_REF_')
            self.ref_names.append(self.ref_files[i][_idx+1:_idx2])


    def load_samples(self,button):
        self.smp_files = askopenfilenames(filetypes=(("Sample files", "*_SMP_results.csv"),))
        button.set(str(len(self.smp_files)) + ' Samples Loaded')
        self.load_samples_button.configure(background='#317256')
        try:
            if len(self.ref_files) * len(self.smp_files) > 0:
                self.run_button.configure(background='#317256')
        except:
            pass
        self.smp_names = []
        for i in range(len(self.smp_files)):
            _idx = self.smp_files[i].rfind('/')
            _idx2 = self.smp_files[i].rfind('_SMP_')
            self.smp_names.append(self.smp_files[i][_idx+1:_idx2])

    def run_search(self):
        try:
            if len(self.ref_files) * len(self.smp_files) > 0:
                HQI = np.zeros((len(self.smp_files),len(self.ref_files)))
                for j in range(len(self.smp_files)):
                    # load sample file
                    smp_position, smp_area, smp_significance = self.load_result_file(self.smp_files[j])
                    for i in range(len(self.ref_files)):
                        # load reference file
                        ref_position, ref_area, ref_significance = self.load_result_file(self.ref_files[i])
                        hqi = int((1 - self.compare_spectra(ref_position, ref_area, ref_significance, smp_position, smp_area, smp_significance)) * 1000)
                        HQI[j,i] = hqi
                self.file_name = asksaveasfilename(filetypes=(("HQI Results", "*.csv"),))
                if self.file_name.find('.csv') == -1:
                    self.file_name = self.file_name + '.csv'
                with open(self.file_name, 'w', newline='') as csvfile:
                        exportdata = csv.writer(csvfile, delimiter=',')
                        exportdata.writerow(self.ref_names)
                        #exportdata.writerow(self.smp_names)
                        for i in range(len(self.smp_files)):
                            row = [self.smp_names[i]]
                            for j in range(len(self.ref_files)):
                                row.append(int(HQI[i,j]))
                            exportdata.writerow(row)
        except:
            pass

    def load_result_file(self, fname):
        with open(fname) as csvfile:
            result_file = csv.reader(csvfile, delimiter=',')
            data = []
            for row in result_file:
                data.append(row)
        position = data[0]
        area = data[1]
        significance = data[2]
        position = list(np.float_(position))
        area = list(np.float_(area))
        significance = list(np.float_(significance))
        position = np.array(position)
        area = np.array(area)
        significance = np.array(significance)
        return position, area, significance
    
    def compare_spectra(self, ref_position, ref_area, ref_significance, smp_position, smp_area, smp_significance):
        # find similar peaks
        threshold = 10
        flag = True
        posi_ = np.array([])
        area_ = np.array([])
        sign_ = np.array([])
        ref_significance_total = np.sum(ref_significance)
        while flag:
            dist_x = np.zeros([len(ref_position), len(smp_position)])
            for i in range(len(ref_position)):
                for j in range(len(smp_position)):
                    dist_x[i,j] = abs(ref_position[i] - smp_position[j])
            idx = np.argmin(dist_x)
            min_min = np.min(dist_x)
            row = int(idx/len(smp_position))
            col = int(idx%len(smp_position))
            posi_ = np.append(posi_,[ref_position[row],smp_position[col]])
            area_ = np.append(area_,[ref_area[row],smp_area[col]])
            sign_ = np.append(sign_,[ref_significance[row],smp_significance[col]])
            ref_position = np.delete(ref_position,row)
            ref_area = np.delete(ref_area,row)
            ref_significance = np.delete(ref_significance,row)
            smp_position = np.delete(smp_position,col)
            smp_area = np.delete(smp_area,col)
            smp_significance = np.delete(smp_significance,col)
            if len(ref_position) * len(smp_position) == 0:
                flag = False
            if min_min > threshold:
                flag = False
                posi_ = posi_[0:-2]
                area_ = area_[0:-2]
                sign_ = sign_[0:-2]
        
        posi_ = np.reshape(posi_,[int(len(posi_)/2),2])
        area_ = np.reshape(area_,[int(len(area_)/2),2])
        sign_ = np.reshape(sign_,[int(len(sign_)/2),2])
        ref_significance_used = np.sum(sign_[:,0])
        y_ = np.array([])
        s_ = np.array([])
        x_ = np.array([])
        for i in range(len(posi_)-1):
            for j in range(i+1,len(posi_)):
                y_ = np.append(y_, [(area_[i,0]-area_[j,0])/(area_[i,0]+area_[j,0]), (area_[i,1]-area_[j,1])/(area_[i,1]+area_[j,1])])
                s_ = np.append(s_, np.min([sign_[i,0], sign_[j,0], sign_[i,1], sign_[j,1]]))
                x_ = np.append(x_, ((posi_[i,0]-posi_[i,1])**2 + (posi_[j,0]-posi_[j,1])**2)**0.5)
        y_ = np.reshape(y_,[int(len(y_)/2),2])
        dy = ((y_[:,0]-y_[:,1])**2)**0.5
        dx = x_
        k1 = 1.2 # Empirical factors
        k2 = 15  # Empirical factors
        k3 = 4.7 # Empirical factors
        k4 = 5.3 # Empirical factors
        dz = 1 - 1/((np.exp(k1*dx-k2)+1)*(np.exp(k3*dy-k4)+1))
        d = np.sum(dz*s_/np.sum(s_))**(ref_significance_used/ref_significance_total)
        if d == 0:
            d = 1
        return d