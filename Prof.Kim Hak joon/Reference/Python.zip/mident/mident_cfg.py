"""
@author: Gerrit Renner
date: 2019-02-06

title: config module
"""

# LOAD PACKAGES
# external
from tkinter import ttk
import os
import csv

class module_cfg:
    def __init__(self, master, status, main):
        for widget in master.winfo_children():
            widget.destroy()
        self.master = master
        status.set('Configurations')

        # load cfg file
        '''___Master Path___________________________________________________'''
        master_path = os.path.dirname(__file__)
        master_path = master_path[0:master_path.find("\\" + "Python" + "\\") + 8]
        cfg_master_file = master_path + 'mident_config.nfo'
        with open(cfg_master_file) as csvfile:
            cfg_master_csv = csv.reader(csvfile, delimiter='~')
            cfg = []
            for row in cfg_master_csv:
                cfg.append(row)
        cfg = cfg[0]
        cfg_dict = {}
        for i in range(len(cfg)):
        	cfg_dict[cfg[i][1:cfg[i].find(' = ')]] = cfg[i][cfg[i].find(' = ')+3:-1]
        	
        # set labels 
        self.heading_fit = ttk.Label(self.master,text='Data Preprocessing', font=(None, 18, 'bold')).grid(row=1, sticky='e')
        self.fit_xunit = ttk.Label(self.master,text='x Unit:', font=(None, 15, 'bold')).grid(row=2, sticky='e')
        self.fit_xunit = ttk.Label(self.master,text='y Unit:', font=(None, 15, 'bold')).grid(row=3, sticky='e')
        self.fit_range = ttk.Label(self.master,text='Data Range:', font=(None, 15, 'bold')).grid(row=4, sticky='e')
        self.fit_importmode = ttk.Label(self.master,text='Import Only?:', font=(None, 15, 'bold')).grid(row=5, sticky='e')

        # set entries
        self.entry_xunit = ttk.Entry(self.master, font=(None, 12, 'bold'))
        self.entry_xunit.insert(0,cfg_dict.get('xunit'))
        self.entry_xunit.grid(row=2, column=1)

        self.entry_yunit = ttk.Entry(self.master, font=(None, 12, 'bold'))
        self.entry_yunit.insert(0,cfg_dict.get('yunit'))
        self.entry_yunit.grid(row=3, column=1)

        self.entry_datarage = ttk.Entry(self.master, font=(None, 12, 'bold'))
        self.entry_datarage.insert(0,cfg_dict.get('datarange'))
        self.entry_datarage.grid(row=4, column=1)

        self.entry_importmode = ttk.Entry(self.master, font=(None, 12, 'bold'))
        self.entry_importmode.insert(0,cfg_dict.get('importmode'))
        self.entry_importmode.grid(row=5, column=1)