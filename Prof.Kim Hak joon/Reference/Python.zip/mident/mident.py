"""
@author: Gerrit Renner
date: 2019-02-06

title: internal functions
"""

# LOAD PACKAGES
# external
import numpy as np
from scipy import interpolate, stats
from scipy import special
from scipy.signal import savgol_filter, argrelextrema
import matplotlib.pyplot as plt
from scipy.sparse import identity,spdiags
from scipy.sparse import csc_matrix, eye, diags
from scipy.sparse.linalg import spsolve
import pywt
from statsmodels.robust import mad
from scipy.optimize import curve_fit
import csv
import statsmodels.api as sm
import tkinter
import matplotlib
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2TkAgg
from matplotlib.figure import Figure
import time
from scipy.interpolate import interp1d
from scipy.interpolate import UnivariateSpline

# Gaussian Function ###########################################################
def gaussian_func(x,parameter):
    x0 = parameter[0::3]
    h = parameter[1::3]
    w = parameter[2::3]
    x = np.repeat(np.transpose(np.matrix(x)), len(x0), axis = 1)
    # Function
    x = x - x0
    gaussian = np.multiply(np.exp(np.square(np.divide(x,w)) * - 0.5), h)
    return np.squeeze(np.asarray(np.sum(gaussian, axis = 1)))

# Asymmetric Pseudo Voigt Function ############################################
def apv_func(x, parameter):
    x0 = parameter[0::5] # Peak Center
    h = parameter[1::5] # Peak Height
    w = parameter[2::5] # Peak Width
    f = parameter[3::5] # Peak Shape Factor
    a = parameter[4::5] # Peak Asymmetry Factor
    x = np.repeat(np.transpose(np.matrix(x)), len(a), axis = 1) # Create X-Matrix
    # Function ----------------------------------------------------------------
    x = x - x0 # Consider Peak Centers
    # Asymmetric Function
    w = np.divide(np.multiply(w,2), 1 + np.exp(np.multiply(x, a)))
    # Gaussian
    gaussian = np.multiply(np.exp(np.square(np.divide(x,w)) * - 0.5), h)
    # Lorentzian
    lorentzian = np.divide(h, np.square(np.divide(x,w)) / 3 + 1)
    # Voigt
    voigt = np.sum(np.multiply(lorentzian, f) + np.multiply(np.subtract(1, f), gaussian),axis = 1)
    return np.squeeze(np.asarray(voigt))

def apv_fit(x, *args):
    x0 = args[0::5] # Peak Center
    h = args[1::5] # Peak Height
    w = args[2::5] # Peak Width
    f = args[3::5] # Peak Shape Factor
    a = args[4::5] # Peak Asymmetry Factor
    x = np.repeat(np.transpose(np.matrix(x)), len(a), axis = 1) # Create X-Matrix
    # Function ----------------------------------------------------------------
    x = x - x0 # Consider Peak Centers
    # Asymmetric Function
    w = np.divide(np.multiply(w,2), 1 + np.exp(np.multiply(x, a)))
    # Gaussian
    gaussian = np.multiply(np.exp(np.square(np.divide(x,w)) * - 0.5), h)
    # Lorentzian
    lorentzian = np.divide(h, np.square(np.divide(x,w)) / 3 + 1)
    # Voigt
    voigt = np.sum(np.multiply(lorentzian, f) + np.multiply(np.subtract(1, f), gaussian), axis = 1)
    return np.squeeze(np.asarray(voigt))

# Whittaker Smooth ############################################################
def WhittakerSmooth(x,w,lambda_,differences=1):
    '''
    This function is a translation in python of the R source code of airPLS version 2.0 by Yizeng Liang and Zhang Zhimin - https://code.google.com/p/airpls
    Reference: Z.-M. Zhang, S. Chen, and Y.-Z. Liang, Baseline correction using adaptive iteratively reweighted penalized least squares. Analyst 135 (5), 1138-1146 (2010).
    '''
    '''
    Penalized least squares algorithm for background fitting
    
    input
        x: input data (i.e. chromatogram of spectrum)
        w: binary masks (value of the mask is zero if a point belongs to peaks and one otherwise)
        lambda_: parameter that can be adjusted by user. The larger lambda is,  the smoother the resulting background
        differences: integer indicating the order of the difference of penalties
    
    output
        the fitted background vector
    '''
    X=np.matrix(x)
    m=X.size
    i=np.arange(0,m)
    E=eye(m,format='csc')
    D=E[1:]-E[:-1] # numpy.diff() does not work with sparse matrix. This is a workaround.
    W=diags(w,0,shape=(m,m))
    A=csc_matrix(W+(lambda_*D.T*D))
    B=csc_matrix(W*X.T)
    background=spsolve(A,B)
    return np.array(background)

# airPLS ######################################################################
def airPLS(x, lambda_=100, porder=2, itermax=15):
    '''
    This function is a translation in python of the R source code of airPLS version 2.0 by Yizeng Liang and Zhang Zhimin - https://code.google.com/p/airpls
    Reference: Z.-M. Zhang, S. Chen, and Y.-Z. Liang, Baseline correction using adaptive iteratively reweighted penalized least squares. Analyst 135 (5), 1138-1146 (2010).
    '''
    '''
    Adaptive iteratively reweighted penalized least squares for baseline fitting
    
    input
        x: input data (i.e. chromatogram of spectrum)
        lambda_: parameter that can be adjusted by user. The larger lambda is,  the smoother the resulting background, z
        porder: adaptive iteratively reweighted penalized least squares for baseline fitting
    
    output
        the fitted background vector
    '''
    m=x.shape[0]
    w=np.ones(m)
    for i in range(1,itermax+1):
        z=WhittakerSmooth(x,w,lambda_, porder)
        d=x-z
        dssn=np.abs(d[d<0].sum())
        if(dssn<0.001*(abs(x)).sum() or i==itermax):
            if(i==itermax): 
                print('WARING max iteration reached!')
            break
        w[d>=0]=0 # d>0 means that this point is part of a peak, so its weight is set to 0 in order to ignore it
        w[d<0]=np.exp(i*np.abs(d[d<0])/dssn)
        w[0]=np.exp(i*(d[d<0]).max()/dssn) 
        w[-1]=w[0]
    return z

# Check for Significant Peak Prominence #######################################
def peak_combination(x,parameter,baseline):
    # number of peaks
    n_peaks = int(len(parameter)/5)
    index_vector = np.linspace(0,n_peaks-1,n_peaks,dtype=int)
    # peak positions
    peak_positions = parameter[0::5]
    peak_heights = parameter[1::5]
    positions_index = np.zeros(n_peaks,dtype=int)
    for i in range(0,len(peak_positions)):
        positions_index[i] = np.argmin(abs(peak_positions[i] - x))
    # fitted spectrum
    y_fitted = apv_func(x,parameter) + baseline
    # check for peak positions that occure at local minimum
    _filter = (y_fitted[positions_index] < y_fitted[positions_index+1]) * (y_fitted[positions_index] < y_fitted[positions_index-1])
    positions_index[_filter] =  positions_index[_filter] + 1 
    
    # combine peaks with identical position
    n_unique_positions = len(np.unique(positions_index))
    unique_peaks = [None] * n_unique_positions
    unique_positions_index = np.unique(positions_index)
    for i in range(n_unique_positions):
        unique_peaks[i] = positions_index[positions_index == unique_positions_index[i]]
    # combine left sided peaks with no turning point
    _not_empty = [None]*n_unique_positions
    for i in range(n_unique_positions-1):
        # left sided peak
        actual_main_peak = max(unique_peaks[i])
        # right sided neighbour
        neighbour_peak = min(unique_peaks[i+1]+1)
        # tmp dataset
        _tmp_data = y_fitted[actual_main_peak:neighbour_peak]
        _local_minima = argrelextrema(_tmp_data, np.less)
        # test for minimum and combine peaks if needed
        if len(_local_minima[0]) == 0: # np.argmin(_tmp_data) == 0:
            # add actual peaks to new array
            unique_peaks[i+1] = np.append(unique_peaks[i+1],unique_peaks[i])
            # delete actual peaks from old array
            unique_peaks[i] = [None]
        _not_empty[i] = type(unique_peaks[i]) is np.ndarray
    _not_empty[-1] = type(unique_peaks[-1]) is np.ndarray
    
    # delete empty peak arrays
    unique_peaks2 = [None] * sum(_not_empty)
    j = 0
    for i in range(n_unique_positions):
        if _not_empty[i]:
            unique_peaks2[j] = unique_peaks[i]
            j = j+1
    unique_peaks = unique_peaks2
    
    # combine right sided peaks with no turning point
    _not_empty = [None] * len(unique_peaks)
    for i in range(len(unique_peaks)-1):
        j = len(unique_peaks) - i -1
        # right sided peak
        actual_main_peak = min(unique_peaks[j]+1)
        # left sided neighbour
        neighbour_peak = max(unique_peaks[j-1])
        # tmp dataset
        _tmp_data = y_fitted[neighbour_peak:actual_main_peak]
        _local_minima = argrelextrema(_tmp_data, np.less)
        # test for minimum and combine peaks if needed
        if len(_local_minima[0]) == 0:
            # add actual peaks to new array
            unique_peaks[j-1] = np.append(unique_peaks[j-1],unique_peaks[j])
            # delete actual peaks from old array
            unique_peaks[j] = [None]
        _not_empty[j] = type(unique_peaks[j]) is np.ndarray
    _not_empty[0] = type(unique_peaks[0]) is np.ndarray

    # delete empty peak arrays
    unique_peaks2 = [None] * sum(_not_empty)
    j = 0
    for i in range(len(unique_peaks)):
        if _not_empty[i]:
            unique_peaks2[j] = unique_peaks[i]
            j = j+1
    unique_peaks = unique_peaks2
    # define index vector
    index_vector2 = []
    for i in range(len(unique_peaks)):
        _index = []
        for j in range(len(unique_peaks[i])):
            actual_index = index_vector[unique_peaks[i][j] == positions_index]
            _index = np.append(_index,actual_index)
        _index = np.unique(_index)
        index_vector2 = np.append(index_vector2,_index * 0 + _index[0])

    return index_vector2

# Initialize Peaks (MASTER FUNCTION) ##########################################
def peak_init(x,y,y_raw):
    # x:     x Data
    # y:     y Data (smoothed + baseline corrected)
    # y_raw: y Data (baseline corrected)
    
    # Preset Fit Values
    pre_y = np.array([])
    parameter = np.array([])
    peak_x = np.array([])
    peak_y = np.array([])
    pre_residues = y
    rel_residues = 1
    k = -1
    while rel_residues > 0.05:
        k = k + 1
        if k == 0:
            pre_residues = savgol_filter(pre_residues,11,2)
        # Main Peaks
        main_x, main_y, main_p, filt = peakProminence(x, pre_residues)
        peak_x = np.append(peak_x,main_x[filt])
        peak_y = np.append(peak_y,main_y[filt])
        peak_x, peak_y = correctPosition(x,y_raw,peak_x)
        peak_x, indices = np.unique(peak_x,return_index=True)
        peak_y = peak_y[indices]
        charc_x, charc_y = characteristicPoints(x,y_raw,peak_x,peak_y,'right')
        charc_x2, charc_y2 = characteristicPoints(x,y_raw,peak_x,peak_y,'left')
        pre_widths = (charc_x - charc_x2)/2
        # check if peak_x and charc_x are equal
        peak_x = peak_x[pre_widths > 0]
        peak_y = peak_y[pre_widths > 0]
        pre_widths = pre_widths[pre_widths > 0]
        # Filter Water Bands
        min_width = 1.5
        min_wavenumber = 1800
        _filter = (peak_x > min_wavenumber) * (pre_widths < min_width)
        peak_x = peak_x[~_filter]
        peak_y = peak_y[~_filter]
        pre_widths = pre_widths[~_filter]        
        # Delete Double Bands
        _filter = np.array([True],dtype=bool)
        for band in peak_x:
            # check distances
            _distances = np.sort(abs(peak_x - band))
            if (_distances[1] < 2) * (_filter[-1]):
                _filter = np.append(_filter,[False])#False
            else:
                _filter = np.append(_filter,[True])
        _filter = _filter[1:]
        peak_x = peak_x[_filter]
        peak_y = peak_y[_filter]
        pre_widths = pre_widths[_filter]  
        # Filter Bands with Width or Height = 0
        _filter = (peak_y < np.std(np.diff(y_raw))*3) + (pre_widths == 0)
        peak_x = peak_x[~_filter]
        peak_y = peak_y[~_filter]
        pre_widths = pre_widths[~_filter] 
        # Set Parameters
        parameter = np.zeros(len(peak_x)*3)
        parameter[0::3] = peak_x
        parameter[1::3] = peak_y
        parameter[2::3] = pre_widths
        # Correct heights of overlayed peaks
        # peaks*heights = y
        peaks = []
        for i in range(len(peak_x)):
            peaks.append(np.exp( -.5 * ((peak_x[i] - peak_x) / pre_widths)**2))
        try:
            heights = np.linalg.solve(peaks,peak_y)
            print('peak initialize optimal')
        except:
            heights = peak_y
            print('peak initialize not optimal')
        parameter[1::3] = heights
        # Filter negative heights
        _filter = np.repeat(parameter[1::3] > 0, 3)
        parameter = parameter[_filter]
        # Parameter for residues calculation
        parameter_estimated = np.zeros(len(parameter))
        parameter_estimated[0::3] = parameter[0::3]
        parameter_estimated[1::3] = parameter[1::3]#*1.2
        parameter_estimated[2::3] = parameter[2::3]#*1.2
        # Calculate residues
        y_estimated = gaussian_func(x,parameter_estimated)
        pre_residues = y - y_estimated
        pre_residues[pre_residues < 0] = 0
        rel_residues = sum(pre_residues) / sum(y)
        parameter_fitted = parameter
        if k == 3:
            rel_residues = 0
    # Filter Water Spikes
    pos = parameter_fitted[0::3]
    heights = parameter_fitted[1::3]
    widths = parameter_fitted[2::3]
    _filter = (pos > min_wavenumber) * (widths < min_width)
    _filter = _filter + (pos > min_wavenumber) * (heights < 0.05)
    pos = pos[~_filter]
    heights = heights[~_filter]
    widths = widths[~_filter]
    # Set Parameters
    results_parameter = np.zeros(len(pos)*5)
    results_parameter[0::5] = pos
    results_parameter[1::5] = heights
    results_parameter[2::5] = widths
    results_parameter[3::5] = 0
    results_parameter[4::5] = 0
    return results_parameter
    

# Is Number Function ##########################################################
def is_number(x):
    try:
        float(x)
        return True
    except ValueError:
        return False
   
# Wavelet Denoise #############################################################
def waveletSmooth( x, wavelet="db4", level=1, title=None ):
    '''
    This function was created by Connor Johnson - http://connor-johnson.com/2016/01/24/using-pywavelets-to-remove-high-frequency-noise/
    '''
    # calculate the wavelet coefficients
    coeff = pywt.wavedec( x, wavelet, mode="per" )
    # calculate a threshold
    sigma = mad( coeff[-level] )
    # changing this threshold also changes the behavior,
    # but I have not played with this very much
    uthresh = sigma * np.sqrt( 2*np.log( len( x ) ) )
    coeff[1:] = ( pywt.threshold( i, value=uthresh, mode="soft" ) for i in coeff[1:] )
    # reconstruct the signal using the thresholded coefficients
    y = pywt.waverec( coeff, wavelet, mode="per" )
    return y

# Find Peaks with Prominence ##################################################
def peakProminence(x,y):
    # find all local maxima in a window of n = 5 datapoints
    n = 5
    b1 = (y[(n-5):-(n-1)] < y[(n-4):-(n-2)])
    b2 = (y[(n-4):-(n-2)] < y[(n-3):-(n-3)])
    b3 = (y[(n-3):-(n-3)] > y[(n-2):-(n-4)])
    b4 = (y[(n-2):-(n-4)] > y[(n-1):])
    
    B1 = b1
    B2 = ~b2
    B3 = ~b3
    B4 = b4
    B5 = y[(n-3):-(n-3)] > y[(n-5):-(n-1)]
    B6 = y[(n-3):-(n-3)] > y[(n-1):]
    
    peak_index = np.append([False, False],b1 * b2 * b3 * b4 + B1 * B2 * B3 * B4 * B5 * B6)
    peak_index = np.append(peak_index, [False, False])
    
    if len(x) == len(peak_index):
        peak_x = x[peak_index]
        peak_y = y[peak_index]
    else:
        peak_x = x[peak_index[0:-1]]
        peak_y = y[peak_index[0:-1]]
    peak_prominence = np.zeros(len(peak_x))
    
    for i in range(0,len(peak_x)):
        # current peak
        curr_peak_x = peak_x[i]
        curr_peak_y = peak_y[i]
        # peaks that are higher than current peak
        if curr_peak_y < max(peak_y):
            higher_peaks_x = peak_x[peak_y > curr_peak_y]
            # closest higher peak
            idx = np.argmin(abs(curr_peak_x - higher_peaks_x))
            next_peak_x = higher_peaks_x[idx]
            if next_peak_x != curr_peak_x:
                # calculate prominence
                tmp_start = min([curr_peak_x , next_peak_x])
                tmp_stop = max([curr_peak_x , next_peak_x])
                tmp_y = y[(x > tmp_start) * (x < tmp_stop)]
                peak_prominence[i] = curr_peak_y - min(tmp_y)
        else:
            peak_prominence[i] = curr_peak_y - min(y)
    
    # mean diff y
    mean_diff_y = np.mean(abs(np.diff(y)))
    std_diff_y = np.std(abs(np.diff(y)))
    _filter = peak_prominence > mean_diff_y + 2 * std_diff_y
        
    return peak_x, peak_y, peak_prominence, _filter


# Correct Peak Positions ######################################################
def correctPosition(x,y,peak_x):
    corr_x = np.zeros(len(peak_x))
    corr_y = np.zeros(len(peak_x))
    for j in range(len(peak_x)):
        i = np.argmin(abs(x - peak_x[j]))
        actual_pos = x[i]
        actual_y = y[i]
        if (i > 1) * (i<len(x)-3):
            actual_test_range = y[i-2:i+2]
            if max(actual_test_range) == actual_y:
                flag = False
            else:
                flag = True
        else:
            flag = False
        while flag:
            i = np.argmax(actual_test_range) - 2 + i
            actual_pos = x[i]
            actual_y = y[i]
            if (i > 1) * (i<len(x)-3):
                actual_test_range = y[i-2:i+2]
                if max(actual_test_range) == actual_y:
                    flag = False
                else:
                    flag = True
            else:
                flag = False
        corr_x[j] = actual_pos
        corr_y[j] = actual_y
    return corr_x,corr_y
        

# Find Characteristic Points ##################################################
def characteristicPoints(x,y,peak_x,peak_y,direction='right'):
    charc_x = np.zeros(len(peak_x))
    charc_y = np.zeros(len(peak_x)) 
    if direction == 'right':
        if len(peak_x) > 0:
            for i in range(len(peak_x)-1):
                x_range = x[(x >= peak_x[i]) * (x <= peak_x[i+1])]
                y_range = y[(x >= peak_x[i]) * (x <= peak_x[i+1])]
                fwhm_y = y_range[y_range <= peak_y[i]/2]
                fwhm_x = x_range[y_range <= peak_y[i]/2]
                try:
                    fwhm_y = fwhm_y[0]
                    fwhm_x = fwhm_x[0]
                except:
                    fwhm_y = min(y_range)
                    fwhm_x = x_range[np.argmin(y_range)]
                charc_x[i] = fwhm_x
                charc_y[i] = fwhm_y
            
            
            i = len(peak_x) - 1
            x_range = x[x >= peak_x[i]]
            y_range = y[x >= peak_x[i]]
            fwhm_y = y_range[y_range <= peak_y[i]/2]
            fwhm_x = x_range[y_range <= peak_y[i]/2]
            try:
                fwhm_y = fwhm_y[0]
                fwhm_x = fwhm_x[0]
            except:
                fwhm_y = min(y_range)
                fwhm_x = x_range[np.argmin(y_range)]
            charc_x[i] = fwhm_x
            charc_y[i] = fwhm_y

    if direction == 'left':
        if len(peak_x) > 0:
            for i in range(len(peak_x)):
                if i == 0:
                    charc_x[i] = 0
                    charc_y[i] = 0
                else:
                    x_range = x[(x <= peak_x[i]) * (x >= peak_x[i-1])]
                    y_range = y[(x <= peak_x[i]) * (x >= peak_x[i-1])]
                    fwhm_y = y_range[y_range <= peak_y[i]/2]
                    fwhm_x = x_range[y_range <= peak_y[i]/2]
                    try:
                        fwhm_y = fwhm_y[-1]
                        fwhm_x = fwhm_x[-1]
                    except:
                        fwhm_y = min(y_range)
                        fwhm_x = x_range[np.argmin(y_range)]
                    charc_x[i] = fwhm_x
                    charc_y[i] = fwhm_y
            
            
            i = 0
            x_range = x[x <= peak_x[i]]
            y_range = y[x <= peak_x[i]]
            fwhm_y = y_range[y_range <= peak_y[i]/2]
            fwhm_x = x_range[y_range <= peak_y[i]/2]
            try:
                fwhm_y = fwhm_y[-1]
                fwhm_x = fwhm_x[-1]
            except:
                fwhm_y = min(y_range)
                fwhm_x = x_range[np.argmin(y_range)]
            charc_x[i] = fwhm_x
            charc_y[i] = fwhm_y
            

    return charc_x, charc_y
                   
def running_mean(x, N):
    cumsum = np.cumsum(np.insert(x, 0, 0)) 
    return (cumsum[N:] - cumsum[:-N]) / float(N)


def ir_smooth(x,y, _window = 360, _overlap = 60):
    N = int(np.trunc(len(x) / _overlap))
    Y = np.zeros([len(x),N])
    for i in range(N):
        xtmp = x[i*_overlap:(i+1)*_overlap + (_window - _overlap)]
        ytmp = y[i*_overlap:(i+1)*_overlap + (_window - _overlap)]
        x1,y1,y2,W = variable_smooth(xtmp,ytmp)
        Y[i*_overlap:(i+1)*_overlap + (_window - _overlap),i] = y2 
    
    Y[Y==0] = np.nan
    Ymedian = np.nanmedian(Y,axis=1)
    return Ymedian

def variable_smooth(x,y):
    W = 100
    _window = 11
    while W > 3E-2:
        y2 = savgol_filter(y,_window,2)
        _fft = np.fft.fft(y2)
        _fft = np.sort(_fft.real)
        x1,y1,w = width_fft(_fft,x)
        W = w
        _window = _window + 2
    return x1,y1,y2,W

def width_fft(_fft,x):
    _fft = _fft[:-1]
    _fft,_idx = np.unique(_fft,return_index = True)
    _iqr = stats.iqr(_fft)
    x1 = x[:-1]
    x1 = x[_idx]
    x1 = (x1 - min(x1)) / (max(x1) - min(x1))
    
    _quart75 = np.percentile(_fft,75)
    _quart25 = np.percentile(_fft,25)
    _idx = (_fft > _quart25 - 1.5 * _iqr) * (_fft < _quart75 + 1.5 * _iqr)
    _fft = _fft[_idx]
    x1 = x1[_idx]
    
    f = interp1d(_fft,x1)
    x2 = np.linspace(min(_fft),max(_fft),2*len(_fft))
    y2 = f(x2)
    
    f = UnivariateSpline(x2,y2, k=5)
    y3 = f(x2)
    y3 = savgol_filter(y3,11,2,deriv=1)
    _idx = argrelextrema(y3, np.greater)
    _idx2 = argrelextrema(y3, np.less)
    try:
        w = abs(np.min(np.max(x2[_idx]) - x2[_idx2]))
    except:
        w = 0
    return x2,y3,w
             
def plot_data(x,y,master):
    # create figure
    f = Figure(figsize=(100,100),
               dpi=100, facecolor='#333333')
    a = f.add_subplot(111,facecolor='#333333')
    for child in a.get_children():
        if isinstance(child, matplotlib.spines.Spine):
            child.set_color('#bbbbbb')
    a.set_xlabel(cfg_dict.get('xunit'),fontweight='bold', fontsize=16)
    a.set_ylabel(cfg_dict.get('yunit'),fontweight='bold', fontsize=16)
    a.xaxis.label.set_color('#bbbbbb')
    a.yaxis.label.set_color('#bbbbbb')
    a.tick_params(axis='x', colors='#bbbbbb')
    a.tick_params(axis='y', colors='#bbbbbb')
    a.invert_xaxis()
    a.plot(x,y,lw=3,color='#EE3135')
    f.set_tight_layout(True)
    canvas = FigureCanvasTkAgg(f, master)
    canvas.draw()
    canvas.get_tk_widget().pack(side=tkinter.BOTTOM, fill=tkinter.BOTH, expand=True)
    canvas._tkcanvas.pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=True)
