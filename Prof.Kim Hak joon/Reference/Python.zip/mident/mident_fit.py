"""
@author: Gerrit Renner
date: 2019-02-06

title: fit module
"""

# LOAD PACKAGES
# external
import time
from scipy.optimize import curve_fit, minimize
import numpy as np
import scipy.integrate as integrate
import csv
import os
import pandas as pd
from matplotlib.figure import Figure
import matplotlib
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2TkAgg

# internal
import mident
from mident_libsearch import *
import importApit

class module_fit:
    def __init__(self, master, fnames, items, status, main):
        for widget in master.winfo_children():
            widget.destroy()
        self.fit_que(fnames,master, items, status, main)
        
    def fit_que(self, fnames,master, items, status, main):
        start_time = time.time()
        for i in range(len(fnames)):
            for widget in master.winfo_children():
                widget.destroy()
            if i == len(fnames) - 1:
                libsearch = False
            else:
                libsearch = False
            self.fit_spectrum(fnames[i],master,items[i],libsearch) 
            av_time_fit = (time.time() - start_time) / (i+1)
            time_to_go = (len(fnames) - i - 1) * av_time_fit
            
            print('Average time per fit: ' + str(round(av_time_fit)) + ' seconds')
            print('Time till Job is done: ' + str(round(time_to_go)) + ' seconds')
            print('_________ ' + str(i + 1) + ' of ' + str(len(fnames)) + ' _____')
            status.set('(' + str(int((i+1)/len(fnames)*100)) + ' %), Spectrum ' + str(i + 1) + ' of ' + str(len(fnames)) + ', Time till Job is done: ' + str(round(time_to_go)) + ' seconds')
            main.update()
        status.set('(' + str(int((i+1)/len(fnames)*100)) + ' %), Spectrum ' + str(i + 1) + ' of ' + str(len(fnames)) + ', Time: ' + str(round((time.time() - start_time))) + ' seconds')
        main.update()
        
    
    def fit_spectrum(self,spectrum,master,items,libsearch=False):
        # load cfg file
        '''___Master Path___________________________________________________'''
        master_path = os.path.dirname(__file__)
        master_path = master_path[0:master_path.find("\\" + "Python" + "\\") + 8] #+ 'database' + '\\'
        cfg_master_file = master_path + 'mident_config.nfo'
        with open(cfg_master_file) as csvfile:
            cfg_master_csv = csv.reader(csvfile, delimiter='~')
            cfg = []
            for row in cfg_master_csv:
                cfg.append(row)
        cfg = cfg[0]
        cfg_dict = {}
        for i in range(len(cfg)):
            cfg_dict[cfg[i][1:cfg[i].find(' = ')]] = cfg[i][cfg[i].find(' = ')+3:-1]
        '''___DEBUG MODE____________________________________________________'''
        debug_mode = False
        '''___IMPORT MODE____________________________________________________'''
        import_mode = False
        '''___WAVELET DENOISE_______________________________________________'''
        wavelet_denoise = False
        '''___Master Path___________________________________________________'''
        master_path = os.path.dirname(__file__)
        master_path = master_path[0:master_path.find("\\" + "Python" + "\\") + 8] + 'database' + '\\'
        '''___Import Data___________________________________________________'''
        for i in range(0,len(spectrum)):
            if spectrum[i] == '.':
                flag = i
        data_type = spectrum[flag+1:]
        if data_type == 'amap':
            data_type = 'apit'
        if data_type == 'apit':
            if import_mode:
                try:
                    x,y,table_x,table_y = importApit.import_apit(spectrum, calc_mean=False, KK_transform=False, cut=True, extend=True, mapping=False)
                except:
                    x,y = importApit.import_apit(spectrum, calc_mean=False, KK_transform=False, cut=True, extend=True, mapping=False)
            else:
                try:
                    x,y,table_x,table_y = importApit.import_apit(spectrum, calc_mean=False, KK_transform=False, cut=True, extend=True, mapping=True)
                except:
                    x,y = importApit.import_apit(spectrum, calc_mean=False, KK_transform=False, cut=True, extend=True, mapping=True)
            flag = 1

        if data_type == 'txt':
            print('load txt file')
            x = []
            y = []
            with open(spectrum, newline='') as csvfile:
                data = csv.reader(csvfile, delimiter='\t')
                for row in data:
                    if len(row) > 1:
                        row[0] = row[0].replace(',','.')
                        row[1] = row[1].replace(',','.')
                        x = np.append(x, float(row[0]))
                        y = np.append(y, float(row[1]))
            y = y[(x>700) == (x<1850)]
            x = x[(x>700) == (x<1850)] 
            flag = 1

        if data_type == 'csv':
            print('load csv file')
            with open(spectrum, newline='') as csvfile:
                data = csv.reader(csvfile,delimiter=',')
                i = 0
                for row in data:
                    i = i+1
                    if i == 1:
                        x = [float(i) for i in row]
                        x = np.array(x)
                    if i == 2:
                        y = [float(i) for i in row]
                        y = np.array(y)
            y = y[(x>700) == (x<2200)]
            x = x[(x>700) == (x<2200)]
            flag = 1
        print('loading complete')
        
        if import_mode:
            print('only import')
            '''___Baseline Correction___________________________________________''' 
            number_of_measurements = np.shape(y)
            try: 
                number_of_measurements = number_of_measurements[1]
            except:
                number_of_measurements = 1
            print('baseline correction complete')
            '''___Export________________________________________________________'''
            for i in range(number_of_measurements):
                filename_raw = master_path + items[1] + '_' + str(i+1) + '_raw.csv'
                with open(filename_raw, 'w', newline='') as csvfile:
                    exportdata = csv.writer(csvfile, delimiter=',')
                    exportdata.writerow(x)
                    exportdata.writerow(y[:,i])
            try:
                filename_raw = master_path + items[1] + '_' + str(i+1) + '_pos.csv'        
                with open(filename_raw, 'w', newline='') as csvfile:
                    exportdata = csv.writer(csvfile, delimiter=',')
                    exportdata.writerow(np.array([table_x,table_y]))
            except:
                pass
        else:
            '''___Check if Spectrum is relevant_________________________________'''
            df = pd.DataFrame(y)
            y_smooth = df.rolling(25,center=True,min_periods=1).mean()
            y_movingAV = df.rolling(500,center=True,min_periods=1).mean()
            criterion = np.mean(((y_smooth - y_movingAV)**2)**.5)
            criterion[0] = 1
            if criterion[0] < .06:
                print('no relevant data loaded')
            else:
                y = y[x < 2200]
                x = x[x < 2200]
                '''___Smoothing ____________________________________________________''' 
                y_smooth = mident.ir_smooth(x,y)
                yOLD = y
                y = y_smooth
                '''___Baseline Correction___________________________________________''' 
                baseline = mident.airPLS(y,lambda_=80,porder=2)
                df = pd.DataFrame(baseline)
                baseline_smooth = df.rolling(100,center=True,min_periods=1).mean()
                baseline = np.min([baseline_smooth.values[:,0],baseline],axis=0)
                y_baseline = y - baseline
                print('baseline correction complete')
                '''___Correct Spikes________________________________________________'''
                if wavelet_denoise:
                    # Wavelet Denoise
                    y_den_wavelet = mident.waveletSmooth(y_baseline)
                    # Water Denoise
                    baseline3 = mident.waveletSmooth(y_den_wavelet,level=3)
                    _weighting_vector = (erf((x-1400)*.3)+1)/2
                    try:
                        y_den_wavelet = y_den_wavelet[:-1] * (1-_weighting_vector) + baseline3[:-1] * _weighting_vector
                    except:
                        y_den_wavelet = y_den_wavelet[:-1] * (1-_weighting_vector[:-1]) + baseline3[:-1] * _weighting_vector[:-1]                        
                    y_den_wavelet = np.append(y_den_wavelet,0)
                else:
                    y_den_wavelet = np.append(y_baseline,0)
                '''___Initialise Peaks______________________________________________'''
                parameter = mident.peak_init(x, y_den_wavelet[:-1],y_baseline)
                #exit()
                print('peak initialize complete')
                '''___Curve Fit_____________________________________________________'''
                # cut spectrum
                xold = x
                yold = y
                y = y_baseline
                parameter_broad = parameter.copy()
                parameter_broad[2::5] = parameter_broad[2::5]*1.5
                y_init = mident.apv_func(xold,parameter_broad)
                y_init2 = y_init
                # min number of points that are higher than threshold
                min_number = 10#5
                threshold = .002
                # binary filter
                binary_filter = np.min([y, y_init],axis=0) > threshold
                flag_start = 0
                cut_start = []
                for i in range(0,len(y) - min_number):
                    if flag_start == 0:
                        if sum(binary_filter[i:i + min_number]) == min_number:
                            flag_start = 1
                            cut_start = np.append(cut_start, xold[i])
                    
                    if flag_start == 1:
                        if binary_filter[i] == False:
                            flag_start = 0
                            cut_start = np.append(cut_start, xold[i])
                if len(cut_start) % 2 != 0:            
                    cut_start = np.append(cut_start,max(xold))
                x_cut = np.reshape(cut_start,[int(len(cut_start)/2),2])     
                n_cut = np.size(x_cut,0)
                print('Cut complete')
                # parameter
                p_position = parameter[0::5]
                p_height = parameter[1::5]
                p_width = parameter[2::5]
                p_shape = parameter[3::5]
                p_asym = parameter[4::5]
                parameter_fitted = []
                parameter_err = []
                # reduce data to significant datapoints
                x_relevant = np.array([])
                y_relevant = np.array([])
                for i in range(len(p_position)):
                    # first peak
                    if i == 0:
                        tmp_start = xold[0]
                        tmp_end = p_position[i+1]
                    # last peak
                    if i == len(p_position)-1:
                        tmp_start = p_position[i-1]
                        tmp_end = xold[-1]
                    # other peaks
                    if (i>0)*(i<len(p_position)-1):
                        tmp_start = p_position[i-1]
                        tmp_end = p_position[i+1]    
                    x_tmp = xold[(xold>=tmp_start)*(xold<=tmp_end)]
                    y_tmp = y[(xold>=tmp_start)*(xold<=tmp_end)]
                    x_center = x_tmp[np.argmin(np.abs(x_tmp-p_position[i]))]
                    y_center = y_tmp[np.argmin(np.abs(x_tmp-p_position[i]))]
                    x_min_left = x_tmp[np.argmin(y_tmp[x_tmp<=x_center])]
                    x_min_right = x_tmp[np.argmin(y_tmp[x_tmp>=x_center])+len(y_tmp[x_tmp<x_center])]
                    
                    x_left = x_tmp[(x_tmp>=x_min_left)*(x_tmp<=x_center)]
                    y_left = y_tmp[(x_tmp>=x_min_left)*(x_tmp<=x_center)]
                    y_left_norm = (y_left - min(y_left))/(max(y_left - min(y_left)))
                    x_left50 = x_left[np.argmin(abs(y_left_norm - .5))]
                    y_left50 = y_left[np.argmin(abs(y_left_norm - .5))]
                    x_left25 = x_left[np.argmin(abs(y_left_norm - .25))]
                    y_left25 = y_left[np.argmin(abs(y_left_norm - .25))]
                    
                    x_right = x_tmp[(x_tmp>=x_center)*(x_tmp<=x_min_right)]
                    y_right = y_tmp[(x_tmp>=x_center)*(x_tmp<=x_min_right)]
                    y_right_norm = (y_right - min(y_right))/(max(y_right - min(y_right)))
                    x_right50 = x_right[np.argmin(abs(y_right_norm - .5))]
                    y_right50 = y_right[np.argmin(abs(y_right_norm - .5))]
                    x_right25 = x_right[np.argmin(abs(y_right_norm - .25))]
                    y_right25 = y_right[np.argmin(abs(y_right_norm - .25))]
                    
                    x_tmp,_index = np.unique(np.array([x_left[0], x_left25, x_left50, x_center, x_right50, x_right25, x_right[-1]]),return_index=True)
                    y_tmp = np.array([y_left[0], y_left25, y_left50, y_center, y_right50, y_right25, y_right[-1]])
                    y_tmp = y_tmp[_index]
                    x_relevant = np.append(x_relevant, x_tmp)
                    y_relevant = np.append(y_relevant, y_tmp)
                
                x_relevant,_index = np.unique(x_relevant,return_index=True)
                y_relevant = y_relevant[_index]
                
                for i in range(n_cut):
                    x_tmp = xold[(xold>=x_cut[i,0])==(xold<=x_cut[i,1])] #
                    y_tmp = y[(xold>=x_cut[i,0])==(xold<=x_cut[i,1])] #
                    tmp_p_position = p_position[(p_position>=x_cut[i,0])==(p_position<=x_cut[i,1])]
                    tmp_p_height = p_height[(p_position>=x_cut[i,0])==(p_position<=x_cut[i,1])]
                    tmp_p_width = p_width[(p_position>=x_cut[i,0])==(p_position<=x_cut[i,1])]
                    tmp_p_shape = p_shape[(p_position>=x_cut[i,0])==(p_position<=x_cut[i,1])]
                    tmp_p_asym = p_asym[(p_position>=x_cut[i,0])==(p_position<=x_cut[i,1])]
                    tmp_parameter = np.append(tmp_p_position, tmp_p_height)
                    tmp_parameter = np.append(tmp_parameter, tmp_p_width)
                    tmp_parameter = np.append(tmp_parameter, tmp_p_shape)
                    tmp_parameter = np.append(tmp_parameter, tmp_p_asym)
                    tmp_parameter = np.reshape(tmp_parameter,[5,int(len(tmp_parameter)/5)])
                    tmp_parameter = np.reshape(np.transpose(tmp_parameter),[np.size(tmp_parameter),1])
                    # limits
                    lo = np.zeros([len(tmp_parameter),1])
                    lo[0::5] = tmp_parameter[0::5] - 10
                    lo[1::5] = tmp_parameter[1::5] * .5
                    lo[2::5] = tmp_parameter[2::5] * .2
                    lo[3::5] = 0
                    lo[4::5] = -.9 / tmp_parameter[2::5]
                    
                    up = np.zeros([len(tmp_parameter),1])
                    up[0::5] = tmp_parameter[0::5] + 10
                    up[1::5] = tmp_parameter[1::5] * 10 + 1
                    up[2::5] = tmp_parameter[2::5] * 2 + 1
                    up[3::5] = 1
                    up[4::5] = .9 / tmp_parameter[2::5]
                    if len(tmp_parameter[:,0]) != 0:
                        try:
                            yfit = curve_fit(mident.apv_fit,x_tmp,y_tmp,p0=tmp_parameter[:,0],bounds=[lo[:,0],up[:,0]],method='trf',maxfev=1000)
                            # parameter errors
                            err_ = []
                            for i in range(len(yfit[0])):
                                try:
                                    err_ = np.append(err_, np.absolute(yfit[1][i,i])**0.5)
                                except:
                                    err_ = np.append(err_,0)
                            # check for negative peaks
                            tmp_heights = yfit[0]
                            tmp_heights = tmp_heights[1::5]
                            while sum(tmp_heights < 0) > 0:
                                _filter = np.repeat(tmp_heights > 0,5)
                                tmp_parameter = tmp_parameter[_filter]
                                lo = lo[_filter,0]
                                up = up[_filter,0]
                                yfit = curve_fit(mident.apv_fit,x_tmp,y_tmp,p0=tmp_parameter[:,0],bounds=[lo[:,0],up[:,0]],method='trf',maxfev=1000)
                                tmp_heights = yfit[0]
                                tmp_heights = tmp_heights[1::5]
                            parameter_fitted = np.append(parameter_fitted, yfit[0])
                            parameter_err = np.append(parameter_err, err_)
                        except:
                            try:
                                tmp_parameter2 = np.append(tmp_parameter[:,0],tmp_parameter[:,0])
                                lo = np.append(lo[:,0],lo[:,0])
                                up = np.append(up[:,0],up[:,0])
                                yfit = curve_fit(mident.apv_fit,x_tmp,y_tmp,p0=tmp_parameter2,bounds=[lo,up],method='trf',maxfev=1000)

                                # parameter errors
                                err_ = []
                                for i in range(len(yfit[0])):
                                    try:
                                        err_ = np.append(err_, np.absolute(yfit[1][i,i])**0.5)
                                    except:
                                        err_ = np.append(err_,0)
                                parameter_fitted = np.append(parameter_fitted, yfit[0])
                                paramter_err = np.append(parameter_err, err_)
                                print('re-fitted')
                            except:
                                print('sorry no fit')
                                parameter_fitted = np.append(parameter_fitted, tmp_parameter[:,0])
                                paramter_err = np.append(parameter_err, np.ones(len(tmp_parameter[:,0]))*np.Inf)
                yfit = mident.apv_func(xold,parameter_fitted)
                print('Fit complete')   
                # sort parameter
                _tmp_position = parameter_fitted[0::5]
                _tmp_height = parameter_fitted[1::5]
                _tmp_width = parameter_fitted[2::5]
                _tmp_shape = parameter_fitted[3::5]
                _tmp_asym = parameter_fitted[4::5]
                _index = sorted(range(len(_tmp_position)),key=lambda x:_tmp_position[x])
                _tmp_position = _tmp_position[_index]
                _tmp_height = _tmp_height[_index]
                _tmp_width = _tmp_width[_index]
                _tmp_shape = _tmp_shape[_index]
                _tmp_asym = _tmp_asym[_index]
                 # check for out-of-range peaks
                _oor_filter = (_tmp_position < min(xold)) + (_tmp_position > max(xold))
                
                _parameter = np.zeros(sum(~_oor_filter)*5)#parameter_fitted * 0
                _parameter[0::5] = _tmp_position[~_oor_filter]
                _parameter[1::5] = _tmp_height[~_oor_filter]
                _parameter[2::5] = _tmp_width[~_oor_filter]
                _parameter[3::5] = _tmp_shape[~_oor_filter]
                _parameter[4::5] = _tmp_asym[~_oor_filter]
                parameter_fitted = _parameter

                # check for spikes
                _spike_filter = parameter_fitted[2::5] > 2
                parameter_fitted = parameter_fitted[np.repeat(_spike_filter,5)]

                peak_blacklist = [1]
                flag = 0
                # Delete Bad Peaks
                TPOS = parameter_fitted[0::5]
                err = np.zeros(int(len(parameter_fitted)/5))
                for i in range(int(len(parameter_fitted)/5)):
                    tmp_param = parameter_fitted[i*5:(i+1)*5]
                    x_tmp = xold[(xold > tmp_param[0]-tmp_param[2])*(xold < tmp_param[0] + tmp_param[2])]
                    y_tmp_fit = yfit[(xold > tmp_param[0]-tmp_param[2])*(xold < tmp_param[0] + tmp_param[2])]
                    y_tmp_raw = y[(xold > tmp_param[0]-tmp_param[2])*(xold < tmp_param[0] + tmp_param[2])]
                    err[i] = np.mean(abs(y_tmp_fit - y_tmp_raw)) / tmp_param[1]
                filter_bad = err > 1
                filter_bad = np.repeat(filter_bad,5)
                baseline_new = mident.apv_func(xold,parameter_fitted[filter_bad])
                baseline = baseline + baseline_new
                parameter_fitted = parameter_fitted[~filter_bad]
                
                # check for out-of-range peaks
                while (len(peak_blacklist) > 0) + (flag == 2):
                    _peak_index = mident.peak_combination(xold,parameter_fitted,baseline)
                    print('Peak Overlay complete')
                    
                    '''___Results_______________________________________________________'''
                    i = 0
                    result_position = []
                    result_area = []
                    result_significance = []
                    result_height = []
                    result_width = []
                    _index_lin = np.linspace(0,len(_peak_index)-1,len(_peak_index),dtype=int) 
                    peak_blacklist = []
                    
                    while i < len(_peak_index):
                        actual_peak_index = _peak_index[i]
                        
                        # check for grouping peaks
                        actual_peaks = _index_lin[_peak_index == actual_peak_index]
                        
                        tmp_parameter = parameter_fitted[i*5:actual_peaks[-1]*5+5]
                        y_tmp = mident.apv_func(xold,tmp_parameter)
                        y_tmp2 = mident.apv_func(xold,parameter_fitted)
            
                        tmp_position = tmp_parameter[0::5]
                        tmp_heights = tmp_parameter[1::5]
                        tmp_position = tmp_position[np.argmax(tmp_heights)]
                        tmp_position = xold[np.argmax(y_tmp)]
                        tmp_width = tmp_parameter[2::5]
                        tmp_area = np.trapz(y_tmp,xold,dx=0.1)
                        tmp_filter = y_tmp / max(y_tmp) > .1
                        # filter right side
                        right_peak = max(_index_lin[_peak_index == actual_peak_index]) + 1
                        if right_peak <= max(_index_lin):
                            right_position = parameter_fitted[right_peak*5]
                            right_tmp_y = y_tmp2[(xold < right_position) * (xold >= tmp_position)]
                            right_tmp_x = xold[(xold < right_position) * (xold >= tmp_position)]
                            right_tmp_x = right_tmp_x[np.argmin(right_tmp_y)]
                            right_filter = xold <= right_tmp_x
                        else:
                            right_filter = xold <= max(xold)
                        # filter left side
                        left_peak = min(_index_lin[_peak_index == actual_peak_index]) - 1
                        if left_peak >= 0:
                            left_position = parameter_fitted[left_peak*5]
                            left_tmp_y = y_tmp2[(xold > left_position) * (xold <= tmp_position)]
                            left_tmp_x = xold[(xold > left_position) * (xold <= tmp_position)]
                            left_tmp_x = left_tmp_x[np.argmin(left_tmp_y)]
                            left_filter = xold >= left_tmp_x
                        else:
                            left_filter = xold <= max(xold)          
                        tmp_filter2 = left_filter * right_filter * tmp_filter
                        if len(y[tmp_filter2]) > 3:
                            tmp_significance = max(y[tmp_filter2]) / (sum((y[tmp_filter2] - y_tmp2[tmp_filter2])**2) / sum((y[tmp_filter2] - np.mean(y[tmp_filter2]))**2))**.5
                            result_position = np.append(result_position,tmp_position)
                            result_area = np.append(result_area,tmp_area)
                            result_significance = np.append(result_significance,tmp_significance)
                            result_height = np.append(result_height,max(tmp_heights))
                            result_width = np.append(result_width, sum(tmp_width))
                        else:
                            tmp_significance = 0
                        i = i + sum(_peak_index == actual_peak_index)
                        if tmp_significance < 1e-4 or tmp_significance/tmp_area < 0.01:
                            pass
                    
                    # Delete black listed peaks
                    for i in peak_blacklist:
                        parameter_fitted[int(i)*5:int(i)*5+5] = np.nan
                    
                    parameter_fitted = parameter_fitted[~np.isnan(parameter_fitted)]
                    flag = flag + 1
                
                yfit = mident.apv_func(xold,parameter_fitted)
                print('Results complete')
                '''___Export________________________________________________________'''
                if items[0] == 'reference':
                    filetype = '_REF'
                else:
                    filetype = '_SMP'
                filename = master_path + items[1] + filetype + '_results.csv'
                filename_raw = master_path + items[1] + filetype + '_raw.csv'
                filename_fit = master_path + items[1] + filetype + '_fit.csv'
                database_master_file = master_path + 'database.csv'
                with open(database_master_file) as csvfile:
                    database_master_csv = csv.reader(csvfile, delimiter=',')
                    database_ID = []
                    database_TYPE = []
                    database_NAME = []
                    database_DATE = []
                    database_RAWDATA = []
                    database_RESULTS = []
                    for row in database_master_csv:
                        if len(row) > 0:
                            database_ID.append(row[0])
                            print(database_ID)
                            database_TYPE.append(row[1])
                            database_NAME.append(row[2])
                            database_DATE.append(row[3])
                            database_RAWDATA.append(row[4])
                            database_RESULTS.append(row[5])
                # check if entry already exists
                flag = 0
                for i in range(0,len(database_NAME)):
                    if database_NAME[i] == items[1] and database_DATE[i] == items[2]:
                        flag = i
                
                if flag > 0:
                    print('Entry exists')
                else:
                    print('Entry is new')
                    if len(database_ID) > 1:
                        database_ID.append(int(database_ID[-1]) + 1)
                    else:
                        database_ID.append(10000+len(database_ID))
                    database_TYPE.append(items[0])
                    database_NAME.append(items[1])
                    database_DATE.append(items[2])
                    database_RAWDATA.append(filename_raw)
                    database_RESULTS.append(filename)
                    # export RAW File
                    with open(filename_raw, 'w', newline='') as csvfile:
                        exportdata = csv.writer(csvfile, delimiter=',')
                        exportdata.writerow(xold)
                        exportdata.writerow(yOLD)
                    with open(database_master_file, 'w', newline='') as csvfile:
                        exportdata = csv.writer(csvfile, delimiter=',')
                        for row in range(0,len(database_NAME)):
                            exportdata.writerow([database_ID[row], database_TYPE[row], database_NAME[row], database_DATE[row], database_RAWDATA[row], database_RESULTS[row]])
                  
                with open(filename, 'w', newline='') as csvfile:
                    exportdata = csv.writer(csvfile, delimiter=',')
                    exportdata.writerow(np.transpose(result_position))
                    exportdata.writerow(np.transpose(result_area))
                    exportdata.writerow(np.transpose(result_significance))
                    exportdata.writerow(np.transpose(parameter_fitted))
                    exportdata.writerow(np.transpose(result_width))
                    try:
                        exportdata.writerow(np.array([table_x, table_y]))
                    except:
                        pass

                with open(filename_fit, 'w', newline='') as csvfile:
                        exportdata = csv.writer(csvfile, delimiter=',')
                        exportdata.writerow(xold)
                        exportdata.writerow(yfit)
                        exportdata.writerow(yOLD)
                        exportdata.writerow(baseline)
                
                print('data export complete')
                '''___Plot Data_____________________________________________________'''
                # get frame size
                parentname = master.winfo_parent()
                parent = master._nametowidget(parentname)
                width = parent.winfo_width()-100
                height = parent.winfo_height()-50
                
                # get peak heights
                peak_heights = []
                for pos in result_position:
                    tmp_difference = abs(pos - xold)
                    tmp_index = np.argmin(tmp_difference)
                    peak_heights = np.append(peak_heights,(y[tmp_index]+baseline[tmp_index])*1.07)
                
                # get relative peak significances
                rel_peak_significance = result_significance/np.sum(result_significance)*100
                    
                
                # create figure
                f = Figure(figsize=(width/100,height/100),
                           dpi=100, facecolor='#333333')
                a = f.add_subplot(111,facecolor='#333333')
                for child in a.get_children():
                    if isinstance(child, matplotlib.spines.Spine):
                        child.set_color('#bbbbbb')
                a.set_xlabel(cfg_dict.get('xunit'),fontweight='bold', fontsize=16)
                a.set_ylabel(cfg_dict.get('yunit'),fontweight='bold', fontsize=16)
                a.xaxis.label.set_color('#bbbbbb')
                a.yaxis.label.set_color('#bbbbbb')
                a.tick_params(axis='x', colors='#bbbbbb')
                a.tick_params(axis='y', colors='#bbbbbb')
                a.invert_xaxis()
                
                a.plot([xold[0],xold[0]],[min(yfit+baseline),max(yfit+baseline)*1.3],lw=0)
                a.plot(xold,yfit+baseline,lw=8,color='#EE3135')
                a.scatter(xold,yOLD, marker='+', color='#999999')
                a.scatter(result_position,peak_heights,marker="v",color='#EE3135')
                # plot reference
                try:
                    a.plot(x_ref, y_ref, lw=1, color='#FFAA00',linestyle='--')
                    res_str = "assigned as: " + reference_names[results] + ', HQI = ' + str(hqi)
                    a.set_title(res_str , position = (0.5,0.9), fontweight='bold', fontsize=16, color='#bbbbbb')
                except:
                    pass
                # create annotations
                for i in range(0,len(result_position)):
                    a.text(result_position[i], peak_heights[i]*1.01, str(i+1), fontsize=15,color='white', rotation=45, horizontalalignment='left',  verticalalignment='bottom')
                # calculate normalized root mean squared error
                rmse = (np.mean((yfit+baseline - yOLD)**2))**.5 / (np.max(yOLD) - np.min(yOLD))
                print(rmse)
                f.set_tight_layout(True)
                canvas = FigureCanvasTkAgg(f, master)
                canvas.draw()
                canvas.get_tk_widget().pack(side=tkinter.BOTTOM, fill=tkinter.BOTH, expand=True)
                canvas._tkcanvas.pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=True)
                print('plot complete')